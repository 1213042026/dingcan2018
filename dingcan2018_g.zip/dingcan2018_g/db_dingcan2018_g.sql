/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50521
Source Host           : localhost:3306
Source Database       : db_dingcan2018_g

Target Server Type    : MYSQL
Target Server Version : 50521
File Encoding         : 65001

Date: 2018-03-12 22:38:43
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `t_admin`
-- ----------------------------
DROP TABLE IF EXISTS `t_admin`;
CREATE TABLE `t_admin` (
  `userId` int(11) NOT NULL,
  `userName` varchar(55) DEFAULT NULL,
  `userPw` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_admin
-- ----------------------------
INSERT INTO `t_admin` VALUES ('2', 'admin', 'admin');

-- ----------------------------
-- Table structure for `t_goods`
-- ----------------------------
DROP TABLE IF EXISTS `t_goods`;
CREATE TABLE `t_goods` (
  `id` int(11) NOT NULL,
  `leibieId` int(11) DEFAULT NULL,
  `mingcheng` varchar(50) DEFAULT NULL,
  `jieshao` varchar(5000) DEFAULT NULL,
  `fujian` varchar(50) DEFAULT NULL,
  `jiage` int(11) DEFAULT NULL,
  `tejia` int(11) DEFAULT NULL,
  `shifoutejia` varchar(50) DEFAULT NULL,
  `del` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_goods
-- ----------------------------
INSERT INTO `t_goods` VALUES ('1', '1', '培根芦笋卷', '培根芦笋卷', '/upload/1400660548315.jpg', '22', '22', 'no', 'no');
INSERT INTO `t_goods` VALUES ('2', '1', '巧煎美味西冷牛排\r\n', '巧煎美味西冷牛排', '/upload/1400660600608.jpg', '23', '23', 'no', 'no');
INSERT INTO `t_goods` VALUES ('3', '1', '蜜汁烤三文鱼', '蜜汁烤三文鱼', '/upload/1400660638909.jpg', '100', '100', 'no', 'no');
INSERT INTO `t_goods` VALUES ('4', '2', '奶油西兰花浓汤\r\n', '蜜汁烤三文鱼', '/upload/1400660673974.jpg', '23', '23', 'no', 'no');
INSERT INTO `t_goods` VALUES ('5', '2', '新奥尔良鸡腿肉批萨\r\n', '奶油西兰花浓汤', '/upload/1400660710223.jpg', '22', '22', 'no', 'no');
INSERT INTO `t_goods` VALUES ('6', '3', '什锦吐司披萨\r\n', '奶油西兰花浓汤', '/upload/1400660762572.jpg', '22', '22', 'no', 'no');
INSERT INTO `t_goods` VALUES ('7', '1', '意大利千层面\r\n', '新奥尔良鸡腿肉批萨', '/upload/1400660797884.jpg', '11', '11', 'no', 'no');
INSERT INTO `t_goods` VALUES ('8', '1', '奶油酱意大利面\r\n', '奶油西兰花浓汤', '/upload/1400660847668.jpg', '33', '33', 'no', 'no');

-- ----------------------------
-- Table structure for `t_huiyuan`
-- ----------------------------
DROP TABLE IF EXISTS `t_huiyuan`;
CREATE TABLE `t_huiyuan` (
  `id` int(11) NOT NULL DEFAULT '0',
  `loginname` varchar(50) DEFAULT NULL,
  `loginpw` varchar(50) DEFAULT NULL,
  `xingming` varchar(50) DEFAULT NULL,
  `xingbie` varchar(50) DEFAULT NULL,
  `nianling` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `dianhua` varchar(255) DEFAULT NULL,
  `yue` int(11) DEFAULT NULL,
  `del` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_huiyuan
-- ----------------------------
INSERT INTO `t_huiyuan` VALUES ('2', 'gtest1', '000000', '张飞', '女', '33', '北京路', '13666666666', '6', 'no');
INSERT INTO `t_huiyuan` VALUES ('5', 'liqian', '000000', '李强', '男', '20', '上海路', '13777777777', '0', 'no');
INSERT INTO `t_huiyuan` VALUES ('6', 'test11', 'test11', '张四', '女', '22', '江苏省南京市', '13888888888', '0', 'no');
INSERT INTO `t_huiyuan` VALUES ('7', 'test22', 'test22', '高哥', '女', '28', '江苏省南京市', '13888888888', '0', 'no');

-- ----------------------------
-- Table structure for `t_jieshao`
-- ----------------------------
DROP TABLE IF EXISTS `t_jieshao`;
CREATE TABLE `t_jieshao` (
  `id` varchar(50) NOT NULL,
  `neirong` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_jieshao
-- ----------------------------
INSERT INTO `t_jieshao` VALUES ('1', '<p>企业文化：勤奋、敬业、谨慎、诚信,dddddddddddddddddddddddddd系统aaaaaaaaa</p>');

-- ----------------------------
-- Table structure for `t_leibie`
-- ----------------------------
DROP TABLE IF EXISTS `t_leibie`;
CREATE TABLE `t_leibie` (
  `id` int(11) NOT NULL DEFAULT '0',
  `mingcheng` varchar(255) DEFAULT NULL,
  `del` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_leibie
-- ----------------------------
INSERT INTO `t_leibie` VALUES ('1', '推荐菜系', 'no');
INSERT INTO `t_leibie` VALUES ('2', '冷菜', 'no');
INSERT INTO `t_leibie` VALUES ('3', '炒菜', 'no');
INSERT INTO `t_leibie` VALUES ('4', '炖菜', 'no');
INSERT INTO `t_leibie` VALUES ('5', '座位', 'zuowei');
INSERT INTO `t_leibie` VALUES ('6', '湘菜', 'no');

-- ----------------------------
-- Table structure for `t_liuyan`
-- ----------------------------
DROP TABLE IF EXISTS `t_liuyan`;
CREATE TABLE `t_liuyan` (
  `liuyan_id` int(11) NOT NULL,
  `liuyan_title` varchar(50) DEFAULT NULL,
  `liuyan_content` varchar(5000) DEFAULT NULL,
  `liuyan_date` varchar(50) DEFAULT NULL,
  `liuyan_user` varchar(50) DEFAULT NULL,
  `goods_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`liuyan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_liuyan
-- ----------------------------
INSERT INTO `t_liuyan` VALUES ('7', '留言版留言版留言版留言版留言版', '留言版留言版留言版留言版留言版留言版留言版留言版留言版留言版留言版留言版留言版留言版留言版', '2018-3-10 14:38:30', null, '0');
INSERT INTO `t_liuyan` VALUES ('10', '评论评论', '评论评论', '2018-3-10 14:38:30', '张三', '8');
INSERT INTO `t_liuyan` VALUES ('11', '评论评论', '评论评论评论评论评论评论', '2018-3-10 14:38:30', null, '8');
INSERT INTO `t_liuyan` VALUES ('12', '留言板留言板', '留言板留言板留言板留言板留言板留言板', '2018-3-10 14:38:30', '张三', '0');
INSERT INTO `t_liuyan` VALUES ('14', 'dd', '请输入内容ddddddddddddddddd', '2018-3-12 22:34:50', null, '0');

-- ----------------------------
-- Table structure for `t_mingxi`
-- ----------------------------
DROP TABLE IF EXISTS `t_mingxi`;
CREATE TABLE `t_mingxi` (
  `id` int(11) NOT NULL,
  `orderId` int(11) DEFAULT NULL,
  `goodsId` int(11) DEFAULT NULL,
  `goodsShuliang` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_mingxi
-- ----------------------------
INSERT INTO `t_mingxi` VALUES ('1', '1', '3', '1');
INSERT INTO `t_mingxi` VALUES ('2', '1', '6', '2');
INSERT INTO `t_mingxi` VALUES ('3', '2', '8', '2');
INSERT INTO `t_mingxi` VALUES ('4', '5', '6', '2');
INSERT INTO `t_mingxi` VALUES ('5', '5', '8', '1');
INSERT INTO `t_mingxi` VALUES ('6', '6', '7', '1');
INSERT INTO `t_mingxi` VALUES ('7', '6', '8', '2');
INSERT INTO `t_mingxi` VALUES ('8', '8', '8', '1');
INSERT INTO `t_mingxi` VALUES ('9', '9', '8', '1');
INSERT INTO `t_mingxi` VALUES ('10', '11', '8', '1');

-- ----------------------------
-- Table structure for `t_order`
-- ----------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order` (
  `id` int(11) NOT NULL,
  `bianhao` varchar(50) DEFAULT NULL,
  `xiadanshi` varchar(50) DEFAULT NULL,
  `zt` varchar(50) DEFAULT NULL,
  `songhuodizhi` varchar(50) DEFAULT NULL,
  `fukuanfangshi` varchar(255) DEFAULT NULL,
  `zongjia` int(11) DEFAULT NULL,
  `huiyuanId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_order
-- ----------------------------
INSERT INTO `t_order` VALUES ('4', '20180314074055', '2018-3-10 14:38:30', '已预订', '第六桌', 'dingzhuozi', '0', '2');
INSERT INTO `t_order` VALUES ('5', '20180314074202', '2018-3-10 14:38:30', '待受理', '第三桌', 'diancai', '77', '2');
INSERT INTO `t_order` VALUES ('6', '20180314074838', '2018-3-10 14:38:30', '待受理', '第二桌', 'diancai', '77', '2');
INSERT INTO `t_order` VALUES ('7', '20180314074900', '2018-3-10 14:38:30', '已预订', '第三桌', 'dingzhuozi', '0', '2');
INSERT INTO `t_order` VALUES ('8', '20180425042114', '2018-3-10 14:38:30', '待受理', '第一桌', 'diancai', '33', '2');
INSERT INTO `t_order` VALUES ('9', '20180405024037', '2018-3-10 14:38:30', '待受理', '第一桌', 'diancai', '33', '2');
INSERT INTO `t_order` VALUES ('10', '20180405024045', '2018-3-10 14:38:30', '已预订', '第二桌', 'dingzhuozi', '0', '2');
INSERT INTO `t_order` VALUES ('11', '20180312103550', '2018-03-12 10:35:50', '待受理', '第二桌', 'diancai', '33', '2');
INSERT INTO `t_order` VALUES ('12', '20180312103600', '2018-03-12 10:36:00', '已预订', '第二桌', 'dingzhuozi', '0', '2');

-- ----------------------------
-- Table structure for `t_xinwen`
-- ----------------------------
DROP TABLE IF EXISTS `t_xinwen`;
CREATE TABLE `t_xinwen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `biaoti` varchar(50) DEFAULT NULL,
  `neirong` varchar(5000) DEFAULT NULL,
  `shijian` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_xinwen
-- ----------------------------
INSERT INTO `t_xinwen` VALUES ('4', '111111111111111111111111111', '1111111111111111111', '2018-03-10 14:39:45');
INSERT INTO `t_xinwen` VALUES ('6', 'sssssssssssssssssssssssss', 'sssssssssssssssssssssssssssssss', '2018-03-10 14:39:45');
