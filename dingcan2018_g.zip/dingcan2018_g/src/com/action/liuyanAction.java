package com.action;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.dao.THuiyuanDAO;
import com.dao.TLiuyanDAO;
import com.model.THuiyuan;
import com.model.TLiuyan;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class liuyanAction extends ActionSupport {
	private int liuyanId;
	private String liuyanTitle;
	private String liuyanContent;

	private String goodsId;

	private TLiuyanDAO liuyanDAO;
	private THuiyuanDAO huiyuanDAO;

	private String message;
	private String path;

	public String liuyanMana() {
		List liuyanList = liuyanDAO.findAll();
		Map request = (Map) ServletActionContext.getContext().get("request");
		request.put("liuyanList", liuyanList);
		return ActionSupport.SUCCESS;
	}

	public String liuyanAdd() {
		Map request = (Map) ServletActionContext.getContext().get("request");
		TLiuyan liuyan = new TLiuyan();
		liuyan.setLiuyanContent(liuyanContent);
		liuyan.setLiuyanTitle(liuyanTitle);
		goodsId = (String) request.get("goodsId");
		if("".equals(goodsId) || null == goodsId){
			liuyan.setGoodsId(0);
			this.setPath("liuyanAll.action");
		}else{
			liuyan.setGoodsId(Integer.parseInt(goodsId));
			this.setPath("goodsDetailQian.action?id=" + goodsId);
		}
		liuyan.setLiuyanDate(new Date().toLocaleString());
		Map session = ActionContext.getContext().getSession();

		if (session.get("huiyuan") != null) {
			THuiyuan user = (THuiyuan) session.get("huiyuan");
			liuyan.setLiuyanUser(user.getXingming());

			// �������ö�
			user.setYue(user.getYue() + 1);
			huiyuanDAO.merge(user);
		}

		liuyanDAO.save(liuyan);
		this.setMessage("���Գɹ�");
		
		// this.setPath("liuyanAll.action");
		return "succeed";
		// request.put("msg", "���Գɹ�");
		// return "msg";
	}

	public String liuyanDel() {
		TLiuyan liuyan = liuyanDAO.findById(liuyanId);
		liuyanDAO.delete(liuyan);

		Map request = (Map) ServletActionContext.getContext().get("request");
		request.put("msg", "������Ϣɾ�����");
		return "msg";
	}

	public String liuyanAll() {
		List liuyanList = liuyanDAO.findAll2();
		Map request = (Map) ServletActionContext.getContext().get("request");
		request.put("liuyanList", liuyanList);
		return ActionSupport.SUCCESS;
	}

	public String liuyanByWuPinId() {
		List liuyanList = liuyanDAO.findByProperty("goodsId", goodsId);
		Map request = (Map) ServletActionContext.getContext().get("request");
		request.put("liuyanList", liuyanList);
		return ActionSupport.SUCCESS;
	}

	public String getLiuyanContent() {
		return liuyanContent;
	}

	public void setLiuyanContent(String liuyanContent) {
		this.liuyanContent = liuyanContent;
	}

	public TLiuyanDAO getLiuyanDAO() {
		return liuyanDAO;
	}

	public void setLiuyanDAO(TLiuyanDAO liuyanDAO) {
		this.liuyanDAO = liuyanDAO;
	}

	public int getLiuyanId() {
		return liuyanId;
	}

	public void setLiuyanId(int liuyanId) {
		this.liuyanId = liuyanId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getLiuyanTitle() {
		return liuyanTitle;
	}

	public void setLiuyanTitle(String liuyanTitle) {
		this.liuyanTitle = liuyanTitle;
	}

	public String getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(String goodsId) {
		this.goodsId = goodsId;
	}

	public THuiyuanDAO getHuiyuanDAO() {
		return huiyuanDAO;
	}

	public void setHuiyuanDAO(THuiyuanDAO huiyuanDAO) {
		this.huiyuanDAO = huiyuanDAO;
	}

}
