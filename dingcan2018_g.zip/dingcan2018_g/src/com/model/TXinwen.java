package com.model;

/**
 * TXinwen entity. @author MyEclipse Persistence Tools
 */

public class TXinwen implements java.io.Serializable
{

	// Fields

	private Integer id;
	private String biaoti;
	private String neirong;
	
	private String shijian;

	public Integer getId()
	{
		return id;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public String getBiaoti()
	{
		return biaoti;
	}

	public void setBiaoti(String biaoti)
	{
		this.biaoti = biaoti;
	}

	public String getNeirong()
	{
		return neirong;
	}

	public void setNeirong(String neirong)
	{
		this.neirong = neirong;
	}

	public String getShijian()
	{
		return shijian;
	}

	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}
	
}